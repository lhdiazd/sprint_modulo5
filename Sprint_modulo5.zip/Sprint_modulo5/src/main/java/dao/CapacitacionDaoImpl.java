package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DbConn;
import model.CapacitacionModelo;
import model.TipoUsuario;
import model.Usuario;

public class CapacitacionDaoImpl implements ICapacitacionDao {
	Connection connection;

	public CapacitacionDaoImpl() throws ClassNotFoundException, SQLException{
		connection = DbConn.getConnection();
	}
	
	@Override
	public boolean registrarCapacitacion(CapacitacionModelo capacitacionModelo) {
		boolean registrado = false;
		String queryRegistroString = "INSERT INTO capacitaciones(nombre, detalle) VALUES(?,?)";
		
		try {
			PreparedStatement pst = connection.prepareStatement(queryRegistroString);
			pst.setString(1, capacitacionModelo.getNombre());
			pst.setString(2, capacitacionModelo.getDetalle());
			
			pst.executeUpdate();
			registrado = true;
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return registrado;
	}

	@Override
	public List<CapacitacionModelo> listarCapacitacionModelo() {
		String queryListarString = "SELECT * FROM capacitaciones";

		List<CapacitacionModelo> listaCapacitacion = new ArrayList<CapacitacionModelo>();
		
		try {
			int id = 0;
			String nombre = "";
			String detalle = "";
			PreparedStatement pst = connection.prepareStatement(queryListarString);
			ResultSet rs = pst.executeQuery();
			
			
			while(rs.next()) {
				id = rs.getInt(1);
				nombre = rs.getString(2);
				detalle = rs.getString(3);
				
				CapacitacionModelo capacitacionModelo = new CapacitacionModelo(id, nombre, detalle);
				listaCapacitacion.add(capacitacionModelo);
				
			}
			
			rs.close();
			pst.close();
			connection.close();	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listaCapacitacion;
	}

}
