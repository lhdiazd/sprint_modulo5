package dao;

import java.util.List;

import model.CapacitacionModelo;

public interface ICapacitacionDao {
	public boolean registrarCapacitacion(CapacitacionModelo capacitacionModelo);
	public List<CapacitacionModelo> listarCapacitacionModelo();
}
