package dao;

import java.util.List;

import model.Usuario;

public interface IUsuarioDao {
	public boolean registrarUsuario(Usuario usuario);
	public List<Usuario> listarUsuarios();
	public boolean actualizarUsuario(Usuario usuario);
	public boolean eliminarUsuario(Usuario usuario);
}
