package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.PreparableStatement;

import db.DbConn;
import model.TipoUsuario;
import model.Usuario;

public class UsuarioDaoImpl implements IUsuarioDao {
	Connection connection;

	public UsuarioDaoImpl() throws ClassNotFoundException, SQLException {
		connection = DbConn.getConnection();
	}

	@Override
	public boolean registrarUsuario(Usuario usuario) {
		boolean registrado = false;
		String queryRegistroString = "INSERT INTO usuarios(nombre, tipo) VALUES(?,?)";
		
		try {
			PreparedStatement pst = connection.prepareStatement(queryRegistroString);
			pst.setString(1, usuario.getNombre());
			pst.setString(2, usuario.getTipoUsuario().name());
			
			pst.executeUpdate();
			registrado = true;
			connection.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return registrado;
	}

	@Override
	public List<Usuario> listarUsuarios() {		
		String queryListarString = "SELECT * FROM usuarios";

		List<Usuario> listaUsuario = new ArrayList<Usuario>();
		
		try {
			int id = 0;
			String nombre = "";
			String tipoUsuario = "";
			PreparedStatement pst = connection.prepareStatement(queryListarString);
			ResultSet rs = pst.executeQuery();
			
			
			while(rs.next()) {
				id = rs.getInt(1);
				nombre = rs.getString(2);
				tipoUsuario = rs.getString(3);
				
				Usuario usuario = new Usuario(id, nombre, TipoUsuario.valueOf(tipoUsuario));
				listaUsuario.add(usuario);
				
			}
			
			rs.close();
			pst.close();
			connection.close();	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listaUsuario;
		
	}

	@Override
	public boolean actualizarUsuario(Usuario usuario) {
		boolean actualizado = false;
		String queryActualizarString = "UPDATE usuarios SET nombre = ?, tipo = ? WHERE id = ?";

		try {
			PreparedStatement pst = connection.prepareStatement(queryActualizarString);
			pst.setString(1, usuario.getNombre());
			pst.setString(2, usuario.getTipoUsuario().name());
			pst.setInt(3, usuario.getId()); 
			
			pst.executeUpdate();
			
			actualizado = true;
			pst.close();
			connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return actualizado;
		
	}

	@Override
	public boolean eliminarUsuario(Usuario usuario) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
