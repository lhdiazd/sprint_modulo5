package model;

public class Administrativo extends Usuario {

	public Administrativo(String nombre, TipoUsuario tipoUsuario) {
		super(nombre, tipoUsuario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Administrativo [getId()=" + getId() + ", getNombre()=" + getNombre() + ", getTipoUsuario()="
				+ getTipoUsuario() + ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";
	}
	
	
	
}
