package model;

public class Cliente extends Usuario{

	public Cliente(String nombre, TipoUsuario tipoUsuario) {
		super(nombre, tipoUsuario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Cliente [getId()=" + getId() + ", getNombre()=" + getNombre() + ", getTipoUsuario()=" + getTipoUsuario()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}
	
}
