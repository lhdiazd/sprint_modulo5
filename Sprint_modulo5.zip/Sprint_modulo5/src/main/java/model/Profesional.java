package model;

public class Profesional extends Usuario{

	public Profesional(String nombre, TipoUsuario tipoUsuario) {
		super(nombre, tipoUsuario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Profesional [getId()=" + getId() + ", getNombre()=" + getNombre() + ", getTipoUsuario()="
				+ getTipoUsuario() + ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + "]";
	}
	
}
