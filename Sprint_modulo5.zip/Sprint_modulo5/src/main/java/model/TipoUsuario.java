package model;

public enum TipoUsuario {
	Cliente,
    Administrativo,
    Profesional
}
