package model;

public class Usuario {
	private int id;
	private String nombre;
	private TipoUsuario tipoUsuario;
	
	public Usuario( String nombre, TipoUsuario tipoUsuario) {				
		this.nombre = nombre;
		this.tipoUsuario = tipoUsuario;
	}
	

	public Usuario(int id, String nombre, TipoUsuario tipoUsuario) {		
		this.id = id;
		this.nombre = nombre;
		this.tipoUsuario = tipoUsuario;
	}


	public int getId() {
		return id;
	}


	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public TipoUsuario getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(TipoUsuario tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nombre=" + nombre + ", tipoUsuario=" + tipoUsuario + "]";
	}
	
	
}
