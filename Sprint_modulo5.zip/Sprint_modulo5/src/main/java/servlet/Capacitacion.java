package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CapacitacionModelo;
import model.TipoUsuario;
import model.Usuario;

import java.io.IOException;
import java.sql.SQLException;

import dao.CapacitacionDaoImpl;
import dao.UsuarioDaoImpl;
import model.CapacitacionModelo;/**
 * Servlet implementation class Capacitacion
 */
public class Capacitacion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Capacitacion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/capacitacion.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}
		String nombre = request.getParameter("nombre-capacitacion");
		String detalle = request.getParameter("detalle-capacitacion");
		try {
			CapacitacionModelo capacitacionModelo= new CapacitacionModelo(nombre, detalle);			
			CapacitacionDaoImpl capacitacionDaoImpl = new CapacitacionDaoImpl();		
			if (capacitacionDaoImpl.registrarCapacitacion(capacitacionModelo)) {
		        response.sendRedirect("resultadoCreacionCapacitacion.jsp?resultado=exito");
		    } else {
		    	response.sendRedirect("resultadoCreacionCapacitacion.jsp?resultado=fracaso");
		    }
			
		} catch (ClassNotFoundException | SQLException e) {			
			e.printStackTrace();
			response.sendRedirect("LoginServlet");
		}
	}

}
