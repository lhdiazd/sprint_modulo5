package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class Contacto
 */
public class Contacto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Contacto() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("./LoginServlet");
		    return;
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/contacto.jsp");
			dispatcher.forward(request, response);
		}	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("./LoginServlet");
		    return;
		}else {
			 String nombre = request.getParameter("nombre");
		     String email = request.getParameter("email");
		     String mensaje = request.getParameter("texto");

		        
		     System.out.println("Nombre: " + nombre);
		     System.out.println("Email: " + email);
		     System.out.println("Mensaje: " + mensaje);
		     
		     request.setAttribute("nombre", nombre);
		     request.setAttribute("email", email);
		     request.setAttribute("mensaje", mensaje);
		     
		     if(nombre != null && email != null) {
		    	 RequestDispatcher dispatcher = request.getRequestDispatcher("/contactoExitoso.jsp");
			     dispatcher.forward(request, response);
		     }else {
		    	 response.sendRedirect("./Contacto");
		     }
		     
		     
		}
	}

}
