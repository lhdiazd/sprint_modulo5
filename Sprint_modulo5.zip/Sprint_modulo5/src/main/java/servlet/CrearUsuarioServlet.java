package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.TipoUsuario;
import model.Usuario;

import java.io.IOException;
import java.sql.SQLException;

import dao.UsuarioDaoImpl;

/**
 * Servlet implementation class CrearUsuarioServlet
 */
public class CrearUsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrearUsuarioServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/crearUsuario.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}
		String nombre = request.getParameter("nombre-usuario");
		TipoUsuario tipo = TipoUsuario.valueOf(request.getParameter("tipo-usuario"));
		try {
			Usuario usuario = new Usuario(nombre, tipo);			
			UsuarioDaoImpl usuarioDaoImpl = new UsuarioDaoImpl();			
			if (usuarioDaoImpl.registrarUsuario(usuario)) {
		        response.sendRedirect("resultadoRegistro.jsp?resultado=exito");
		    } else {
		    	response.sendRedirect("resultadoRegistro.jsp?resultado=fracaso");
		    }
			
		} catch (ClassNotFoundException | SQLException e) {			
			e.printStackTrace();
			response.sendRedirect("LoginServlet");
		}
		
		
		
		
		
		
		
	}

}
