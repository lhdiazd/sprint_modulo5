package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.TipoUsuario;
import model.Usuario;

import java.io.IOException;
import java.sql.SQLException;

import dao.UsuarioDaoImpl;

/**
 * Servlet implementation class EditarProfesionalServlet
 */
public class EditarProfesionalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditarProfesionalServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}else {
			String idUsuario = request.getParameter("id");		    
		    int idUsuarioInt = Integer.parseInt(idUsuario);
		    request.setAttribute("idUsuario", idUsuarioInt);		    
			RequestDispatcher dispatcher = request.getRequestDispatcher("/editarProfesional.jsp");
			dispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}
		String nombre = request.getParameter("nombre-usuario");
		TipoUsuario tipo = TipoUsuario.valueOf(request.getParameter("tipo-usuario"));
		int idUsuario = Integer.parseInt(request.getParameter("id-usuario"));
		
		try {
			Usuario usuario = new Usuario(idUsuario, nombre, tipo);			
			UsuarioDaoImpl usuarioDaoImpl = new UsuarioDaoImpl();			
			if (usuarioDaoImpl.actualizarUsuario(usuario)) {
		        response.sendRedirect("resultadoActualizacion.jsp?resultado=exito");
		    } else {
		    	response.sendRedirect("resultadoActualizacion.jsp?resultado=fracaso");
		    }
			
		} catch (ClassNotFoundException | SQLException e) {			
			e.printStackTrace();
			response.sendRedirect("LoginServlet");
		}
	}

}
