package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.CapacitacionModelo;
import model.Usuario;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.CapacitacionDaoImpl;
import dao.UsuarioDaoImpl;

/**
 * Servlet implementation class ListarCapacitacion
 */
public class ListarCapacitacion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListarCapacitacion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}else {				
			try {							
				CapacitacionDaoImpl capacitacionDaoImpl = new CapacitacionDaoImpl();			
				List<CapacitacionModelo> listaCapacitacion = new ArrayList<CapacitacionModelo>();
				
				listaCapacitacion = capacitacionDaoImpl.listarCapacitacionModelo();
				request.setAttribute("capacitaciones", listaCapacitacion);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/listarCapacitacion.jsp");
				dispatcher.forward(request, response);
				
			} catch (ClassNotFoundException | SQLException e) {			
				e.printStackTrace();
				response.sendRedirect("LoginServlet");
			}
			
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("rut") == null) {			 
		    response.sendRedirect("LoginServlet");
		    return;
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/listarCapacitacion.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
